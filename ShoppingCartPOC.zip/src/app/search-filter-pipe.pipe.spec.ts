import { SearchFilterPipePipe } from './search-filter-pipe.pipe';

describe('SearchFilterPipePipe', () => {
  it('create an instance', () => {
    const pipe = new SearchFilterPipePipe();
    expect(pipe).toBeTruthy();
  });
});
